# Desafio Target

Este repositório contém a solução para o desafio técnico da empresa Target Sistemas.

---

## Questões Resolvidas

### 1. Soma de números até um índice
Código em C que soma os números de 1 a 13:
Resultado final: `91`

### 2. Verifica se um número pertence à sequência de Fibonacci
Entrada: Um número inteiro
Saída: Mensagem informando se o número pertence à sequência

### 3. Análise de faturamento mensal
- Menor valor de faturamento
- Maior valor de faturamento
- Número de dias com faturamento acima da média

Fonte de dados: JSON ou XML

### 4. Percentual por estado
Calcula a porcentagem de representação de cada estado no faturamento mensal

### 5. Inversão de string
Código que inverte os caracteres de uma string sem usar funções prontas

---

## Execução
Todos os scripts estão escritos em **Python 3** (exceto a questão 1 que é em C).

Para executar:
```bash
python nome_do_script.py
```

---

## Estrutura do Projeto

```
.
├── questao1
│   └── soma.c
├── questao2
│   └── fibonacci.py
├── questao3
│   ├── dados.json
│   ├── dados.xml
│   └── faturamento.py
├── questao4
│   └── percentual_estados.py
├── questao5
│   └── inverter_string.py
└── README.md
```

---

Feito com 💙 por Matheus
