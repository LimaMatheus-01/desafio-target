// Questão 1 - Soma de 1 a 13
#include <stdio.h>

int main() {
    int INDICE = 13, SOMA = 0, K = 0;

    while (K < INDICE) {
        K = K + 1;
        SOMA = SOMA + K;
    }

    printf("Resultado da soma: %d\n", SOMA);
    return 0;
}
