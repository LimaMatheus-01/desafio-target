# Questão 3 - Análise de Faturamento

import json
import xml.etree.ElementTree as ET

def carregar_dados_json(caminho):
    with open(caminho, "r") as f:
        return json.load(f)

def carregar_dados_xml(caminho):
    tree = ET.parse(caminho)
    root = tree.getroot()
    dados = []
    for row in root.findall("row"):
        valor = float(row.find("valor").text)
        dia = int(row.find("dia").text)
        dados.append({"dia": dia, "valor": valor})
    return dados

def analisar_faturamento(dados):
    valores = [d["valor"] for d in dados if d["valor"] > 0]

    menor = min(valores)
    maior = max(valores)
    media = sum(valores) / len(valores)
    dias_acima = sum(1 for v in valores if v > media)

    print(f"Menor faturamento: R$ {menor:.2f}")
    print(f"Maior faturamento: R$ {maior:.2f}")
    print(f"Dias com faturamento acima da média: {dias_acima}")

# Modo de uso (escolher um dos dois):
# dados = carregar_dados_xml("dados (2).xml")     # Para XML
dados = carregar_dados_json("dados.json")         # Para JSON

analisar_faturamento(dados)
